




const dbconfig = ({
    host: "localhost",
    user: "root",
    password: "",
    database: "job_portal",
})



module.exports = dbconfig;